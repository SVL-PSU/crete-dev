This directory contains the tests for ``zcov``.

These tests are written in the LLVM "shell script test" format and are intended
to be executed using the LLVM ``lit`` tool. See the `lit documentation
http://llvm.org/docs/CommandGuide/lit.html)`_ for more information.
